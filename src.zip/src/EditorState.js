// @flow

import {EditorState} from 'prosemirror-state';

const ProseMirrorEditorState = EditorState;

export default ProseMirrorEditorState;

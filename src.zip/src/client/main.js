"use strict";

var _EditorSchema = _interopRequireDefault(require("../EditorSchema"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// console.log(_EditorSchema.default);
var custom_schema = _EditorSchema


// const { Schema } = require('prosemirror-model')
// const { schema } = require('prosemirror-schema-basic')
// const { addListNodes } = require('prosemirror-schema-list')
// const { addTableNodes } = require('prosemirror-schema-table')
// const { tableNodes } = require('prosemirror-tables')
// const { Step } = require('prosemirror-transform')
// const { readFileSync, writeFile } = require('fs')
//
// // sorting out the schema
// // tableNodes
// var custom_schema = new Schema({
//   nodes: addListNodes(schema.spec.nodes, 'paragraph block*', 'block'),
//   marks: schema.spec.marks
// })
//
//
// console.log(tableNodes());
// // console.log(custom_schema.spec.nodes.append(tableNodes));
//
// // console.log(custom_schema.spec.nodes);
//
// // console.log(custom_schema)
// //
// //
// // // var custom_schema = new Schema({
// // //   nodes: addListNodes(addTableNodes(schema.spec.nodes, 'block+', 'block'), 'paragraph block*', 'block'),
// // //   marks: schema.spec.marks
// // // })
// //
// // doc_json = readFileSync('data/doc.txt', () => { null })
// // doc_json = JSON.parse(doc_json)
// //
// // // read the initial document (or have it somewhere)
// // // var doc_node = Node.fromJSON(custom_schema, doc_json);
// // var doc_node = custom_schema.nodeFromJSON(doc_json)
// //
// // step_jsons = readFileSync('data/step.txt', () => { null })
// // step_jsons = step_jsons.toString().split('\n').filter(Boolean)
// //
// // for (var step_json of step_jsons) {
// //   step_json = JSON.parse(step_json)
// //   for (var step of step_json['steps']) {
// //     var step = Step.fromJSON(custom_schema, step)
// //     var result = step.apply(doc_node)
// //     if (result.failed) {
// //
// //     } else {
// //       doc_node = result.doc
// //       console.log(doc_node.toJSON())
// //     }
// //   }
// // }
// //
// // console.log(doc_node)
// //
// //
// //
// //
// // //

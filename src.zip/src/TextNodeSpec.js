"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
const TextNodeSpec = {
  group: 'inline'
};
var _default = TextNodeSpec;
exports.default = _default;

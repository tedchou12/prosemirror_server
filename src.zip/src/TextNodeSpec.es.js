// @flow

const TextNodeSpec = {
  group: 'inline',
};

export default TextNodeSpec;

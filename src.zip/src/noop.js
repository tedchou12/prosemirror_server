// @flow

const noop: any = function() {};

export default noop;

// @flow

const browser = {
  isMac: () => true,
};

export default browser;

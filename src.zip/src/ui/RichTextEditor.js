// @flow

import {Transform} from 'prosemirror-transform';
import {EditorView} from 'prosemirror-view';
import * as React from 'react';

import createEmptyEditorState from '../createEmptyEditorState';
import Editor from './Editor';
import EditorFrameset from './EditorFrameset';
import EditorToolbar from './EditorToolbar';
import Frag from './Frag';
import uuid from './uuid';

import type {EditorFramesetProps} from './EditorFrameset';
import type {EditorProps} from './Editor';

type Props = EditorFramesetProps &
  EditorProps & { children?: ?any,
  };

type State = {
  editorView: ?EditorView,
};


const EMPTY_EDITOR_RUNTIME = {};

class RichTextEditor extends React.PureComponent<any, any> {
  props: Props;

  state: State;

  _id: string;

  constructor(props: any, context: any) {
    super(props, context);
    this._id = uuid();
    this.state = {
      contentHeight: NaN,
      contentOverflowHidden: false,
      editorView: null,
    };
  }

  render(): React.Element<any> {
    const {
      autoFocus,
      children,
      className,
      disabled,
      embedded,
      header,
      height,
      onChange,
      nodeViews,
      placeholder,
      readOnly,
      width,
      fitToContent,
    } = this.props;

    let {editorState, runtime} = this.props;

    editorState = editorState || createEmptyEditorState();
    runtime = runtime || EMPTY_EDITOR_RUNTIME;

    const {editorView} = this.state;

    const toolbar =
      !!readOnly === true ? null : (
        <EditorToolbar
          disabled={disabled}
          dispatchTransaction={this._dispatchTransaction}
          editorState={editorState || Editor.EDITOR_EMPTY_STATE}
          editorView={editorView}
          readOnly={readOnly}
        />
      );

    const body = (
      <Frag>
        <Editor
          autoFocus={autoFocus}
          disabled={disabled}
          dispatchTransaction={this._dispatchTransaction}
          editorState={editorState}
          embedded={embedded}
          fitToContent={fitToContent}
          id={this._id}
          nodeViews={nodeViews}
          onChange={onChange}
          onReady={this._onReady}
          placeholder={placeholder}
          readOnly={readOnly}
          runtime={runtime}
        />
        {children}
      </Frag>
    );

    return (
      <EditorFrameset
        body={body}
        className={className}
        embedded={embedded}
        fitToContent={fitToContent}
        header={header}
        height={height}
        toolbar={toolbar}
        width={width}
      />
    );
  }

  _dispatchTransaction = (tr: Transform): void => {
    const {onChange, editorState, readOnly} = this.props;
    if (readOnly === true) {
      return;
    }

    if (onChange) {
      // [FS-AFQ][20-FEB-2020]
      // Collaboration
      onChange({
        state: editorState || Editor.EDITOR_EMPTY_STATE,
        transaction: tr        
      });
    }

    
  };

  _onReady = (editorView: EditorView): void => {
    if (editorView !== this.state.editorView) {
      this.setState({editorView});
      const {onReady} = this.props;
      onReady && onReady(editorView);
    }
  };
}

export default RichTextEditor;

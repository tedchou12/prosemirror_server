// @flow

export default function preventEventDefault(e: SyntheticEvent<>): void {
  e.preventDefault();
}
